# Chat-aiBot.
> 🧠 A simple discord bot that can talk with user in a channel.
## Requirement.
> 1. Node Version 12.x
> 2. Discord.js package Version 12.x
> 3. Express package.
> 4. Alexa-bot-api package.
## Setup
> - Copy this repo
> - Replace TOKEN in ```.env``` to your bot token. (⚠️ don't share your bot token with anyone)
> - Get your server Channel id then replace config.json with your Channel ID
> - Click space anywhere in watch.json (To refresh in glitch or something.)
> - Taraaa your bot is now online, try it !
## Image
![Example](https://cdn.discordapp.com/attachments/788306064956588072/788583790204289037/Screenshot_2020-12-16-08-50-21-03.jpg)
